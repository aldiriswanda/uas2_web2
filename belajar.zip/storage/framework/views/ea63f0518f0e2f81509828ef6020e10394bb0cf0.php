<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Data Nilai
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <form action="<?php echo e(route('nilai.update',$nilai->id )); ?>"  method="POST" class="form-item">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Nama Mahasiswa</label>
                        <select name="mahasiswa_id" id="mahasiswa_id" class="form-control">
                            <option value="" disabled selected>--Pilih Mahasiswa--</option>
                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mhs->id); ?>" <?php echo e($nilai->mahasiswa_id == $mhs->id ? 'selected' : ' '); ?> ><?php echo e($mhs->nama_mahasiswa); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Nama Mata Kuliah</label>
                        <select name="makul_id" id="makul_id" class="form-control">
                            <option value="" disabled selected>--Pilih Mata Kuliah--</option>
                            <?php $__currentLoopData = $makul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mk->id); ?>" <?php echo e($nilai->makul_id == $mk->id ? 'selected' : ' '); ?>><?php echo e($mk->nama_makul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Nilai</label>
                        <input type="number" name="nilai" class="form-control col-md-3" id="nilai" placeholder="Masukkan Nilai" value="<?php echo e(is_null
                        ($nilai) ? '' : $nilai->nilai); ?>">
                    </div>

                    <div class="form-group">
                    <button type="submit" class="btn btn-primary float-center" name="simpan">SIMPAN</button>
                    <a href="mahasiswa"class="btn btn-danger float-center">BATAL</a>
                    </div>
                    </form>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dayat\belajar\resources\views/nilai/edit.blade.php ENDPATH**/ ?>