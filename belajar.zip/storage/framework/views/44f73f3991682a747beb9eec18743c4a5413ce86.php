<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Edit Data Mahasiswa</div>

                <div class="card-body">
        
                    <form action="<?php echo e(route('update.mahasiswa', $mahasiswa->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col">

                                    <label for="">ID</label>
                                    <input type="text" name="user_id" class="form-control" placeholder="Tambahkan USER ID" value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->user_id); ?>">
                                    <br>
                                    
                                    <label for="">NPM</label>
                                    <input type="text" name="npm" class="form-control" placeholder="Tambahkan NPM" value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->npm); ?>">
                                    <br>

                                    <label for="">NAMA</label>
                                    <input type="text" name="nama_mahasiswa" class="form-control" placeholder="Tambahkan Nama"  value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->nama_mahasiswa); ?>">
                                    <br>

                                    <label for="">TEMPAT LAHIR</label>
                                    <input type="text" name="tempat_lahir" class="form-control" placeholder="Tambahkan Tempat Lahir"  value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->tempat_lahir); ?>">
                                    <br>

                                    <label for="">TANGGAL LAHIR</label>
                                    <input type="date" name="tgl_lahir" class="form-control" placeholder="Tambahkan Tanggal Lahir"  value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->tgl_lahir); ?>">
                                    <br>
                                    
                                    <label for="">JENIS KELAMIN</label>
                                    <select name="jenis_kelamin" class="form-control">
                                    <option value="">masukkan jenis kelamin</option>
                                    <option value="L" selected="<?php echo e(is_null($mahasiswa)? '' : $mahasiswa->jenis_kelamin=='L'); ?>">Lakian</option>
                                    <option value="P" selected="<?php echo e(is_null($mahasiswa)? '' : $mahasiswa->jenis_kelamin=='P'); ?>">Perempuan</option>
                                    </select>
                                    <br>

                                    <label for="">TELEPON</label>
                                    <input type="text" name="telepon" class="form-control" placeholder="Tambahkan Telepon"  value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->telepon); ?>">
                                    <br>
                                    
                                    <label for="">ALAMAT</label>
                                    <input type="text" name="alamat" class="form-control" placeholder="Tambahkan Alamat"  value="<?php echo e(is_null($mahasiswa) ? '' : $mahasiswa->alamat); ?>">
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="form-row">
                                <div class="col">
                                    <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                                    <a href="<?php echo e(route('mahasiswa')); ?>" class="btn btn-md btn-danger float-right">BATAL</a>
                                </div>
                            </div>
                        </div>
                    </form>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dayat\belajar\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>